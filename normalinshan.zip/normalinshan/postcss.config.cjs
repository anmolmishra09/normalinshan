const config = {
  plugins: {
    tailwindcss: {},
  },
};

module.exports = config;
